package fabian.balanca.naocai;

/** Tela editável na aba Design do NetBeans. */
public class TelaEdicaoFases extends javax.swing.JPanel {
    public TelaEdicaoFases() {
        initComponents();
        if (App.registro != null) { campo0.setText(App.registro[1]); }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        titulo = new javax.swing.JLabel();
        rotulo0 = new javax.swing.JLabel();
        campo0 = new javax.swing.JTextField();
        salvar = new javax.swing.JButton();
        limpar = new javax.swing.JButton();
        voltar = new javax.swing.JButton();

        setPreferredSize(new java.awt.Dimension(800, 540));
        setLayout(null);

        titulo.setText("Alterar Fases");
        add(titulo);
        titulo.setBounds(80, 35, 660, 30);

        rotulo0.setText("Descrição da fase");
        add(rotulo0);
        rotulo0.setBounds(65, 120, 280, 30);
        add(campo0);
        campo0.setBounds(350, 120, 280, 30);

        salvar.setText("Salvar");
        salvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salvarActionPerformed(evt);
            }
        });
        add(salvar);
        salvar.setBounds(130, 370, 160, 35);

        limpar.setText("Limpar");
        limpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                limparActionPerformed(evt);
            }
        });
        add(limpar);
        limpar.setBounds(320, 370, 160, 35);

        voltar.setText("Voltar");
        voltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voltarActionPerformed(evt);
            }
        });
        add(voltar);
        voltar.setBounds(510, 370, 160, 35);
    }// </editor-fold>//GEN-END:initComponents

    private void salvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salvarActionPerformed
        try { String[] valores = new String[] {campo0.getText()}; App.dados.alterar(0, Integer.parseInt(App.registro[0]), valores); App.aviso("Registro salvo com sucesso."); App.abrir("TelaAlteracaoFases"); } catch (Exception ex) { App.aviso(ex.getMessage()); }
    }//GEN-LAST:event_salvarActionPerformed

    private void limparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_limparActionPerformed
        campo0.setText("");
    }//GEN-LAST:event_limparActionPerformed

    private void voltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voltarActionPerformed
        App.abrir("TelaAlteracaoFases");
    }//GEN-LAST:event_voltarActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField campo0;
    private javax.swing.JButton limpar;
    private javax.swing.JLabel rotulo0;
    private javax.swing.JButton salvar;
    private javax.swing.JLabel titulo;
    private javax.swing.JButton voltar;
    // End of variables declaration//GEN-END:variables
}
