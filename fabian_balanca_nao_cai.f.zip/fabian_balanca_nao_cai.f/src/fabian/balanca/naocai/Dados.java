package fabian.balanca.naocai;

import dao.CadastroDao;
import dao.Conexao;
import java.io.IOException;
import java.nio.file.Path;
import java.sql.SQLException;
import java.util.List;

/** Mantém o acesso aos cadastros pelas telas existentes. */
public final class Dados {
    private final Conexao conexao;
    private final List<CadastroDao> cadastros;

    public Dados(Path arquivoXml) throws IOException, SQLException {
        String nome = arquivoXml.getFileName().toString();
        String nomeBanco = nome.replaceFirst("(?i)\\.xml$", "") + ".db";
        conexao = new Conexao(arquivoXml.resolveSibling(nomeBanco), arquivoXml);
        cadastros = List.of(conexao.fases(), conexao.engenheiros(), conexao.funcoes(), conexao.usuarios());
    }

    public List<String[]> listar(int tipo) {
        try {
            return cadastros.get(tipo).listar();
        } catch (SQLException e) {
            throw new IllegalStateException("Falha ao consultar os cadastros: " + e.getMessage(), e);
        }
    }

    public void inserir(int tipo, String... valores) throws SQLException {
        cadastros.get(tipo).inserir(valores);
    }

    public void alterar(int tipo, int id, String... valores) throws SQLException {
        if (!cadastros.get(tipo).alterar(id, valores)) {
            throw new IllegalArgumentException("Registro não encontrado.");
        }
    }

    public void excluir(int tipo, int id) throws SQLException {
        if (!cadastros.get(tipo).excluir(id)) {
            throw new IllegalArgumentException("Registro não encontrado.");
        }
    }

    public String[] autenticar(String email, String senha) throws SQLException {
        return conexao.usuarios().autenticar(email, senha);
    }
}