package view;

/** Tela editável na aba Design do NetBeans. */
public class TelaMenu extends javax.swing.JPanel {
    public TelaMenu() {
        initComponents();
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        titulo = new javax.swing.JLabel();
        abrirFases = new javax.swing.JButton();
        abrirEngenheiros = new javax.swing.JButton();
        abrirFuncoes = new javax.swing.JButton();
        abrirUsuarios = new javax.swing.JButton();
        sair = new javax.swing.JButton();

        setPreferredSize(new java.awt.Dimension(800, 540));
        setLayout(null);

        titulo.setText("Menu principal — Balança-Mas-Não-Cai");
        add(titulo);
        titulo.setBounds(80, 35, 660, 30);

        abrirFases.setText("Manutenção de Fases");
        abrirFases.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                abrirFasesActionPerformed(evt);
            }
        });
        add(abrirFases);
        abrirFases.setBounds(260, 110, 280, 35);

        abrirEngenheiros.setText("Manutenção de Engenheiros");
        abrirEngenheiros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                abrirEngenheirosActionPerformed(evt);
            }
        });
        add(abrirEngenheiros);
        abrirEngenheiros.setBounds(260, 170, 280, 35);

        abrirFuncoes.setText("Manutenção de Funções");
        abrirFuncoes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                abrirFuncoesActionPerformed(evt);
            }
        });
        add(abrirFuncoes);
        abrirFuncoes.setBounds(260, 230, 280, 35);

        abrirUsuarios.setText("Manutenção de Usuários");
        abrirUsuarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                abrirUsuariosActionPerformed(evt);
            }
        });
        add(abrirUsuarios);
        abrirUsuarios.setBounds(260, 290, 280, 35);

        sair.setText("Sair do sistema");
        sair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sairActionPerformed(evt);
            }
        });
        add(sair);
        sair.setBounds(260, 350, 280, 35);
    }// </editor-fold>//GEN-END:initComponents

    private void abrirFasesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_abrirFasesActionPerformed
        App.abrir("TelaManutencaoFases");
    }//GEN-LAST:event_abrirFasesActionPerformed

    private void abrirEngenheirosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_abrirEngenheirosActionPerformed
        App.abrir("TelaManutencaoEngenheiros");
    }//GEN-LAST:event_abrirEngenheirosActionPerformed

    private void abrirFuncoesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_abrirFuncoesActionPerformed
        App.abrir("TelaManutencaoFuncoes");
    }//GEN-LAST:event_abrirFuncoesActionPerformed

    private void abrirUsuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_abrirUsuariosActionPerformed
        App.abrir("TelaManutencaoUsuarios");
    }//GEN-LAST:event_abrirUsuariosActionPerformed

    private void sairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sairActionPerformed
        App.usuario = null; App.abrir("TelaLogin");
    }//GEN-LAST:event_sairActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton abrirEngenheiros;
    private javax.swing.JButton abrirFases;
    private javax.swing.JButton abrirFuncoes;
    private javax.swing.JButton abrirUsuarios;
    private javax.swing.JButton sair;
    private javax.swing.JLabel titulo;
    // End of variables declaration//GEN-END:variables
}
