package view;

public final class App {
 public static Dados dados;
 public static String[] usuario, registro;
 public static javax.swing.JFrame janela;
 public static void aviso(String s) { javax.swing.JOptionPane.showMessageDialog(janela,s); }

 public static void entrar(String email, String senha) {
  try {
   usuario = dados.autenticar(email, senha);
   if (usuario == null) {
    aviso("Usuário ou senha incorretos.");
   } else {
    abrir("TelaMenu");
   }
  } catch (java.sql.SQLException ex) {
   aviso("Falha ao consultar o banco de dados: " + ex.getMessage());
  }
 }

 public static javax.swing.JPanel painel(String nome) throws Exception { return (javax.swing.JPanel)Class.forName("fabian.balanca.naocai."+nome).getDeclaredConstructor().newInstance(); }
 public static void abrir(String nome) { try { janela.setContentPane(painel(nome)); janela.revalidate(); janela.repaint(); } catch(Exception ex) { aviso(ex.toString()); } }
}