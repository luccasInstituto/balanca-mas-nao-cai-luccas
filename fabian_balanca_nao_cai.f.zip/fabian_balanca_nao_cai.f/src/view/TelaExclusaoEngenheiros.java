package view;

/** Tela editável na aba Design do NetBeans. */
public class TelaExclusaoEngenheiros extends javax.swing.JPanel {
    public TelaExclusaoEngenheiros() {
        initComponents();
        carregar();
    }
    private java.util.List<String[]> registros;
    private void carregar() {
        if (App.dados == null) return;
        registros = App.dados.listar(1);
        javax.swing.table.DefaultTableModel modelo = new javax.swing.table.DefaultTableModel(new String[] {"Código", "Nome do engenheiro", "CREA", "Data de admissão (dd/mm/aaaa)"}, 0) { public boolean isCellEditable(int r, int c) { return false; } };
        for (String[] r : registros) modelo.addRow(java.util.Arrays.copyOf(r, 4));
        tabela.setModel(modelo); tabela.setRowHeight(28); tabela.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION); tabela.getTableHeader().setReorderingAllowed(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        titulo = new javax.swing.JLabel();
        rolagem = new javax.swing.JScrollPane();
        tabela = new javax.swing.JTable();
        instrucao = new javax.swing.JLabel();
        executar = new javax.swing.JButton();
        voltar = new javax.swing.JButton();

        setPreferredSize(new java.awt.Dimension(800, 540));
        setLayout(null);

        titulo.setText("Exclusão de Engenheiros");
        add(titulo);
        titulo.setBounds(80, 35, 660, 30);

        rolagem.setViewportView(tabela);

        add(rolagem);
        rolagem.setBounds(55, 100, 690, 280);

        instrucao.setText("Selecione uma linha e clique no botão abaixo.");
        add(instrucao);
        instrucao.setBounds(55, 65, 650, 30);

        executar.setText("Excluir selecionado");
        executar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                executarActionPerformed(evt);
            }
        });
        add(executar);
        executar.setBounds(190, 420, 220, 35);

        voltar.setText("Voltar");
        voltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voltarActionPerformed(evt);
            }
        });
        add(voltar);
        voltar.setBounds(440, 420, 170, 35);
    }// </editor-fold>//GEN-END:initComponents

    private void executarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_executarActionPerformed
        int linha = tabela.getSelectedRow(); if (linha < 0) { App.aviso("Selecione um registro na tabela."); return; } String[] registro = registros.get(linha); if (1 == 3 && App.usuario != null && App.usuario[0].equals(registro[0])) { App.aviso("Não é possível excluir o usuário conectado."); return; } if (javax.swing.JOptionPane.showConfirmDialog(this, "Excluir " + registro[1] + "?", "Confirmar exclusão", javax.swing.JOptionPane.YES_NO_OPTION) == javax.swing.JOptionPane.YES_OPTION) { try { App.dados.excluir(1, Integer.parseInt(registro[0])); carregar(); } catch (Exception ex) { App.aviso(ex.getMessage()); } }
    }//GEN-LAST:event_executarActionPerformed

    private void voltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voltarActionPerformed
        App.abrir("TelaManutencaoEngenheiros");
    }//GEN-LAST:event_voltarActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton executar;
    private javax.swing.JLabel instrucao;
    private javax.swing.JScrollPane rolagem;
    private javax.swing.JTable tabela;
    private javax.swing.JLabel titulo;
    private javax.swing.JButton voltar;
    // End of variables declaration//GEN-END:variables
}
