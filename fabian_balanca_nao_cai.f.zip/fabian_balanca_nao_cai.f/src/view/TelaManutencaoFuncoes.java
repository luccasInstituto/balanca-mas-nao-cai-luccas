package view;

/** Tela editável na aba Design do NetBeans. */
public class TelaManutencaoFuncoes extends javax.swing.JPanel {
    public TelaManutencaoFuncoes() {
        initComponents();
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        titulo = new javax.swing.JLabel();
        acao0 = new javax.swing.JButton();
        acao1 = new javax.swing.JButton();
        acao2 = new javax.swing.JButton();
        acao3 = new javax.swing.JButton();
        voltar = new javax.swing.JButton();

        setPreferredSize(new java.awt.Dimension(800, 540));
        setLayout(null);

        titulo.setText("Manutenção de Funções");
        add(titulo);
        titulo.setBounds(80, 35, 660, 30);

        acao0.setText("Incluir");
        acao0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                acao0ActionPerformed(evt);
            }
        });
        add(acao0);
        acao0.setBounds(270, 110, 260, 35);

        acao1.setText("Consultar");
        acao1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                acao1ActionPerformed(evt);
            }
        });
        add(acao1);
        acao1.setBounds(270, 165, 260, 35);

        acao2.setText("Alterar");
        acao2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                acao2ActionPerformed(evt);
            }
        });
        add(acao2);
        acao2.setBounds(270, 220, 260, 35);

        acao3.setText("Excluir");
        acao3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                acao3ActionPerformed(evt);
            }
        });
        add(acao3);
        acao3.setBounds(270, 275, 260, 35);

        voltar.setText("Voltar ao menu");
        voltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voltarActionPerformed(evt);
            }
        });
        add(voltar);
        voltar.setBounds(270, 350, 260, 35);
    }// </editor-fold>//GEN-END:initComponents

    private void acao0ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_acao0ActionPerformed
        App.abrir("TelaInclusaoFuncoes");
    }//GEN-LAST:event_acao0ActionPerformed

    private void acao1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_acao1ActionPerformed
        App.abrir("TelaConsultaFuncoes");
    }//GEN-LAST:event_acao1ActionPerformed

    private void acao2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_acao2ActionPerformed
        App.abrir("TelaAlteracaoFuncoes");
    }//GEN-LAST:event_acao2ActionPerformed

    private void acao3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_acao3ActionPerformed
        App.abrir("TelaExclusaoFuncoes");
    }//GEN-LAST:event_acao3ActionPerformed

    private void voltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voltarActionPerformed
        App.abrir("TelaMenu");
    }//GEN-LAST:event_voltarActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton acao0;
    private javax.swing.JButton acao1;
    private javax.swing.JButton acao2;
    private javax.swing.JButton acao3;
    private javax.swing.JLabel titulo;
    private javax.swing.JButton voltar;
    // End of variables declaration//GEN-END:variables
}
