package dao;

enum Tabela {
    FASES("fases", "descricao"),
    ENGENHEIROS("engenheiros", "nome", "crea", "admissao"),
    FUNCOES("funcoes", "descricao"),
    USUARIOS("usuarios", "nome", "email", "senha_hash", "email_chave"),
    OBRAS("obras", "descricao", "inicio", "fim", "id_engenheiro", "crea_engenheiro", "admissao_engenheiro");

    final String nome;
    final String[] colunas;

    Tabela(String nome, String... colunas) {
        this.nome = nome;
        this.colunas = colunas;
    }
}