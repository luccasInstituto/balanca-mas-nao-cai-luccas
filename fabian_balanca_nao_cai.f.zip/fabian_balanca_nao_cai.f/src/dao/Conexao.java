package dao;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

/** Abre conexões JDBC e prepara o banco na primeira execução. */
public final class Conexao {
    private final String url;
    private final CadastroDao fases = new CadastroDao(this, Tabela.FASES);
    private final CadastroDao engenheiros = new CadastroDao(this, Tabela.ENGENHEIROS);
    private final CadastroDao funcoes = new CadastroDao(this, Tabela.FUNCOES);
    private final UsuarioDao usuarios = new UsuarioDao(this);
    private final CadastroDao obras = new CadastroDao(this, Tabela.OBRAS);

    public Conexao(Path banco, Path xmlLegado) throws IOException, SQLException {
        Path caminho = banco.toAbsolutePath().normalize();
        Files.createDirectories(caminho.getParent());
        url = "jdbc:sqlite:" + caminho;
        inicializar(xmlLegado);
    }

    public CadastroDao fases() {
        return fases;
    }

    public CadastroDao engenheiros() {
        return engenheiros;
    }

    public CadastroDao funcoes() {
        return funcoes;
    }

    public UsuarioDao usuarios() {
        return usuarios;
    }

    /** Ordem dos campos: descrição, início, fim, código do engenheiro, CREA e admissão. */
    public CadastroDao obras() {
        return obras;
    }

    Connection abrir() throws SQLException {
        Connection banco = DriverManager.getConnection(url);
        try (Statement comando = banco.createStatement()) {
            comando.execute("PRAGMA busy_timeout = 5000");
            comando.execute("PRAGMA foreign_keys = ON");
            return banco;
        } catch (SQLException e) {
            try {
                banco.close();
            } catch (SQLException erroFechamento) {
                e.addSuppressed(erroFechamento);
            }
            throw e;
        }
    }

    private void inicializar(Path xmlLegado) throws IOException, SQLException {
        try (Connection banco = abrir(); Statement comando = banco.createStatement()) {
            comando.execute("BEGIN IMMEDIATE");
            try {
                int versao;
                try (ResultSet resultado = comando.executeQuery("PRAGMA user_version")) {
                    versao = resultado.getInt(1);
                }
                if (versao == 0) {
                    criarTabelas(comando);
                    if (xmlLegado != null && Files.exists(xmlLegado)) {
                        importarXml(banco, xmlLegado);
                    } else {
                        criarExemplos(banco);
                    }
                    comando.execute("PRAGMA user_version = 1");
                } else if (versao != 1) {
                    throw new SQLException("Versão do banco de dados incompatível: " + versao);
                }
                comando.execute("COMMIT");
            } catch (IOException | SQLException | RuntimeException e) {
                try {
                    comando.execute("ROLLBACK");
                } catch (SQLException erroRollback) {
                    e.addSuppressed(erroRollback);
                }
                throw e;
            }
        }
    }

    private static void criarTabelas(Statement comando) throws SQLException {
        comando.execute("""
                CREATE TABLE fases (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    descricao TEXT NOT NULL
                )
                """);
        comando.execute("""
                CREATE TABLE engenheiros (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    nome TEXT NOT NULL,
                    crea TEXT NOT NULL,
                    admissao TEXT NOT NULL
                )
                """);
        comando.execute("""
                CREATE TABLE funcoes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    descricao TEXT NOT NULL
                )
                """);
        comando.execute("""
                CREATE TABLE usuarios (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    nome TEXT NOT NULL,
                    email TEXT NOT NULL,
                    senha_hash TEXT NOT NULL,
                    email_chave TEXT NOT NULL UNIQUE
                )
                """);
        comando.execute("""
                CREATE TABLE obras (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    descricao TEXT NOT NULL,
                    inicio TEXT NOT NULL,
                    fim TEXT,
                    id_engenheiro INTEGER NOT NULL REFERENCES engenheiros(id),
                    crea_engenheiro TEXT,
                    admissao_engenheiro TEXT
                )
                """);
    }

    private void importarXml(Connection banco, Path arquivo) throws IOException, SQLException {
        Properties dados = new Properties();
        try (InputStream entrada = Files.newInputStream(arquivo)) {
            dados.loadFromXML(entrada);
        }
        importarTabela(banco, dados, 0, Tabela.FASES, fases);
        importarTabela(banco, dados, 1, Tabela.ENGENHEIROS, engenheiros);
        importarTabela(banco, dados, 2, Tabela.FUNCOES, funcoes);
        importarTabela(banco, dados, 3, Tabela.USUARIOS, usuarios);
    }

    private static void importarTabela(Connection banco, Properties dados, int tipo,
            Tabela tabela, CadastroDao dao) throws SQLException {
        int ultimo = Integer.parseInt(dados.getProperty(tipo + ".ultimo", "0"));
        int camposLegados = tabela == Tabela.USUARIOS ? 3 : tabela.colunas.length;
        String prefixoTipo = tipo + ".";
        for (String chave : dados.stringPropertyNames()) {
            if (!chave.startsWith(prefixoTipo) || !chave.endsWith(".0")) {
                continue;
            }
            int id = Integer.parseInt(chave.substring(prefixoTipo.length(), chave.length() - 2));
            String prefixo = prefixoTipo + id + ".";
            String[] campos = new String[tabela.colunas.length];
            for (int i = 0; i < camposLegados; i++) {
                campos[i] = dados.getProperty(prefixo + i, "");
            }
            if (tabela == Tabela.USUARIOS) {
                campos[3] = UsuarioDao.chaveEmail(campos[1]);
            }
            dao.importar(banco, id, campos);
            ultimo = Math.max(ultimo, id);
        }
        // Preserva a sequência mesmo se o último registro emitido foi excluído no XML.
        try (PreparedStatement remover = banco.prepareStatement("DELETE FROM sqlite_sequence WHERE name = ?");
             PreparedStatement inserir = banco.prepareStatement("INSERT INTO sqlite_sequence (name, seq) VALUES (?, ?)")) {
            remover.setString(1, tabela.nome);
            remover.executeUpdate();
            inserir.setString(1, tabela.nome);
            inserir.setInt(2, ultimo);
            inserir.executeUpdate();
        }
    }

    private void criarExemplos(Connection banco) throws SQLException {
        fases.importar(banco, 1, "Fundação");
        fases.importar(banco, 2, "Alvenaria");
        fases.importar(banco, 3, "Acabamento");
        engenheiros.importar(banco, 1, "Fabian", "123456", "05/11/2026");
        funcoes.importar(banco, 1, "LIMPEZA");
        String email = "teste@email.com.br";
        usuarios.importar(banco, 1, "Usuario Teste", email, UsuarioDao.gerarHash("12345"), UsuarioDao.chaveEmail(email));
    }
}