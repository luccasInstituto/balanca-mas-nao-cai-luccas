package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.StringJoiner;

/** Operações da tabela indicada pela conexão, na ordem de colunas do cadastro. */
public class CadastroDao {
    private static final DateTimeFormatter DATA = DateTimeFormatter
            .ofPattern("dd/MM/uuuu").withResolverStyle(ResolverStyle.STRICT);

    final Conexao conexao;
    private final Tabela tabela;
    private final String inserirSql;
    private final String alterarSql;
    private final String importarSql;
    private final String colunasConsulta;
    private final int camposConsulta;

    CadastroDao(Conexao conexao, Tabela tabela) {
        this.conexao = conexao;
        this.tabela = tabela;
        String colunas = String.join(", ", tabela.colunas);
        String parametros = String.join(", ", Collections.nCopies(tabela.colunas.length, "?"));
        inserirSql = "INSERT INTO " + tabela.nome + " (" + colunas + ") VALUES (" + parametros + ")";
        importarSql = "INSERT INTO " + tabela.nome + " (id, " + colunas + ") VALUES (?, " + parametros + ")";
        StringJoiner atribuicoes = new StringJoiner(", ");
        for (String coluna : tabela.colunas) {
            atribuicoes.add(coluna.equals("senha_hash") ? "senha_hash = COALESCE(?, senha_hash)" : coluna + " = ?");
        }
        alterarSql = "UPDATE " + tabela.nome + " SET " + atribuicoes + " WHERE id = ?";
        camposConsulta = tabela == Tabela.USUARIOS ? 2 : tabela.colunas.length;
        colunasConsulta = "id, " + String.join(", ", Arrays.copyOf(tabela.colunas, camposConsulta));
    }

    public void inserir(String... valores) throws SQLException {
        String[] campos = preparar(valores, false);
        try (Connection banco = conexao.abrir();
             PreparedStatement comando = banco.prepareStatement(inserirSql)) {
            preencher(comando, 1, campos);
            comando.executeUpdate();
        } catch (SQLException e) {
            verificarEmailDuplicado(e);
            throw e;
        }
    }

    public boolean alterar(int id, String... valores) throws SQLException {
        String[] campos = preparar(valores, true);
        try (Connection banco = conexao.abrir();
             PreparedStatement comando = banco.prepareStatement(alterarSql)) {
            preencher(comando, 1, campos);
            comando.setInt(campos.length + 1, id);
            return comando.executeUpdate() == 1;
        } catch (SQLException e) {
            verificarEmailDuplicado(e);
            throw e;
        }
    }

    public List<String[]> listar() throws SQLException {
        String sql = "SELECT " + colunasConsulta + " FROM " + tabela.nome + " ORDER BY id";
        try (Connection banco = conexao.abrir();
             PreparedStatement comando = banco.prepareStatement(sql);
             ResultSet resultado = comando.executeQuery()) {
            List<String[]> registros = new ArrayList<>();
            while (resultado.next()) {
                registros.add(lerRegistro(resultado));
            }
            return registros;
        }
    }

    public String[] buscarPorId(int id) throws SQLException {
        String sql = "SELECT " + colunasConsulta + " FROM " + tabela.nome + " WHERE id = ?";
        try (Connection banco = conexao.abrir();
             PreparedStatement comando = banco.prepareStatement(sql)) {
            comando.setInt(1, id);
            try (ResultSet resultado = comando.executeQuery()) {
                return resultado.next() ? lerRegistro(resultado) : null;
            }
        }
    }

    public boolean excluir(int id) throws SQLException {
        try (Connection banco = conexao.abrir();
             PreparedStatement comando = banco.prepareStatement("DELETE FROM " + tabela.nome + " WHERE id = ?")) {
            comando.setInt(1, id);
            return comando.executeUpdate() == 1;
        }
    }

    void importar(Connection banco, int id, String... valores) throws SQLException {
        try (PreparedStatement comando = banco.prepareStatement(importarSql)) {
            comando.setInt(1, id);
            preencher(comando, 2, valores);
            comando.executeUpdate();
        }
    }

    String[] preparar(String[] valores, boolean alteracao) {
        if (valores.length != tabela.colunas.length) {
            throw new IllegalArgumentException("Informe todos os campos do cadastro.");
        }
        String[] campos = new String[valores.length];
        for (int i = 0; i < campos.length; i++) {
            campos[i] = valores[i] == null ? null : valores[i].trim();
            boolean opcional = tabela == Tabela.OBRAS && (i == 2 || i >= 4);
            if (campos[i] == null || campos[i].isEmpty()) {
                if (!opcional) {
                    throw new IllegalArgumentException("Preencha todos os campos.");
                }
                campos[i] = null;
            }
        }
        if (tabela == Tabela.ENGENHEIROS) {
            validarData(campos[2]);
        }
        if (tabela == Tabela.OBRAS) {
            validarData(campos[1]);
            validarData(campos[2]);
            validarData(campos[5]);
            try {
                if (Integer.parseInt(campos[3]) <= 0) {
                    throw new NumberFormatException();
                }
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("Informe um código de engenheiro válido.");
            }
        }
        return campos;
    }

    private static void validarData(String data) {
        if (data != null) {
            try {
                LocalDate.parse(data, DATA);
            } catch (DateTimeParseException e) {
                throw new IllegalArgumentException("Informe uma data válida no formato dd/mm/aaaa.");
            }
        }
    }

    private String[] lerRegistro(ResultSet resultado) throws SQLException {
        String[] registro = new String[camposConsulta + 1];
        for (int i = 0; i < registro.length; i++) {
            registro[i] = resultado.getString(i + 1);
        }
        return registro;
    }

    private static void preencher(PreparedStatement comando, int inicio, String[] campos) throws SQLException {
        for (int i = 0; i < campos.length; i++) {
            comando.setString(inicio + i, campos[i]);
        }
    }

    private static void verificarEmailDuplicado(SQLException e) {
        if (e.getErrorCode() == 19 && e.getMessage().contains("usuarios.email_chave")) {
            throw new IllegalArgumentException("Este e-mail já está cadastrado.", e);
        }
    }
}