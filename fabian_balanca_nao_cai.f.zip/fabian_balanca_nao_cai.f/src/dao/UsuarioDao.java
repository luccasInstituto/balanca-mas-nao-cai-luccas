package dao;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public final class UsuarioDao extends CadastroDao {
    private static final SecureRandom ALEATORIO = new SecureRandom();

    UsuarioDao(Conexao conexao) {
        super(conexao, Tabela.USUARIOS);
    }

    @Override
    String[] preparar(String[] valores, boolean alteracao) {
        if (valores.length != 3) {
            throw new IllegalArgumentException("Informe nome, e-mail e senha.");
        }
        String nome = limpar(valores[0]);
        String email = limpar(valores[1]);
        String senha = limpar(valores[2]);
        if (nome.isEmpty() || email.isEmpty() || (!alteracao && senha.isEmpty())) {
            throw new IllegalArgumentException("Preencha todos os campos.");
        }
        if (!email.matches("[^\\s@]+@[^\\s@]+\\.[^\\s@]+")) {
            throw new IllegalArgumentException("Informe um e-mail válido.");
        }
        return new String[] {nome, email, senha.isEmpty() ? null : gerarHash(senha), chaveEmail(email)};
    }

    public String[] autenticar(String email, String senha) throws SQLException {
        String sql = "SELECT id, nome, email, senha_hash FROM usuarios WHERE email_chave = ?";
        try (Connection banco = conexao.abrir();
             PreparedStatement comando = banco.prepareStatement(sql)) {
            comando.setString(1, chaveEmail(email.trim()));
            try (ResultSet resultado = comando.executeQuery()) {
                if (!resultado.next() || !conferir(senha, resultado.getString("senha_hash"))) {
                    return null;
                }
                return new String[] {resultado.getString("id"), resultado.getString("nome"), resultado.getString("email")};
            }
        }
    }

    static String chaveEmail(String email) {
        StringBuilder chave = new StringBuilder(email.length());
        email.codePoints().map(Character::toUpperCase).map(Character::toLowerCase).forEach(chave::appendCodePoint);
        return chave.toString();
    }

    static String gerarHash(String senha) {
        byte[] sal = new byte[16];
        ALEATORIO.nextBytes(sal);
        return Base64.getEncoder().encodeToString(sal) + ":" + derivar(senha, sal);
    }

    private static boolean conferir(String senha, String salvo) {
        String[] partes = salvo.split(":", 2);
        if (partes.length != 2) {
            return false;
        }
        byte[] sal = Base64.getDecoder().decode(partes[0]);
        return MessageDigest.isEqual(derivar(senha, sal).getBytes(StandardCharsets.UTF_8),
                partes[1].getBytes(StandardCharsets.UTF_8));
    }

    private static String derivar(String senha, byte[] sal) {
        PBEKeySpec spec = new PBEKeySpec(senha.toCharArray(), sal, 65536, 256);
        try {
            byte[] hash = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
            return Base64.getEncoder().encodeToString(hash);
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException(e);
        } finally {
            spec.clearPassword();
        }
    }

    private static String limpar(String valor) {
        return valor == null ? "" : valor.trim();
    }
}