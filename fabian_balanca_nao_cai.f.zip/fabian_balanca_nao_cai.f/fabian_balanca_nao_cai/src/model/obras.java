/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.util.Date;
/**
 *
 * @author luccas.ficher
 */
public class obras {
    private int idObra;
    private String Descricao;
    private Date dtInicio;
    private Date dtFim;
    private int idEngenheiro;
    private int nrCrea;
    private Date dtDdmissaoEngenheiro;

    /**
     * @return the idObra
     */
    public int getIdObra() {
        return idObra;
    }

    /**
     * @param idObra the idObra to set
     */
    public void setIdObra(int idObra) {
        this.idObra = idObra;
    }

    /**
     * @return the Descricao
     */
    public String getDescricao() {
        return Descricao;
    }

    /**
     * @param Descricao the Descricao to set
     */
    public void setDescricao(String Descricao) {
        this.Descricao = Descricao;
    }

    /**
     * @return the dtInicio
     */
    public Date getDtInicio() {
        return dtInicio;
    }

    /**
     * @param dtInicio the dtInicio to set
     */
    public void setDtInicio(Date dtInicio) {
        this.dtInicio = dtInicio;
    }

    /**
     * @return the dtFim
     */
    public Date getDtFim() {
        return dtFim;
    }

    /**
     * @param dtFim the dtFim to set
     */
    public void setDtFim(Date dtFim) {
        this.dtFim = dtFim;
    }

    /**
     * @return the idEngenheiro
     */
    public int getIdEngenheiro() {
        return idEngenheiro;
    }

    /**
     * @param idEngenheiro the idEngenheiro to set
     */
    public void setIdEngenheiro(int idEngenheiro) {
        this.idEngenheiro = idEngenheiro;
    }

    /**
     * @return the nrCrea
     */
    public int getNrCrea() {
        return nrCrea;
    }

    /**
     * @param nrCrea the nrCrea to set
     */
    public void setNrCrea(int nrCrea) {
        this.nrCrea = nrCrea;
    }

    /**
     * @return the dtDdmissaoEngenheiro
     */
    public Date getDtDdmissaoEngenheiro() {
        return dtDdmissaoEngenheiro;
    }

    /**
     * @param dtDdmissaoEngenheiro the dtDdmissaoEngenheiro to set
     */
    public void setDtDdmissaoEngenheiro(Date dtDdmissaoEngenheiro) {
        this.dtDdmissaoEngenheiro = dtDdmissaoEngenheiro;
    }
    
}
