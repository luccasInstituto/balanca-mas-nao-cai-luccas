package fabian.balanca.naocai;
public final class App {
 public static Dados dados;
 public static String[] usuario, registro;
 public static javax.swing.JFrame janela;
 public static void aviso(String s) { javax.swing.JOptionPane.showMessageDialog(janela,s); }
 public static void entrar(String email,String senha) { usuario=dados.autenticar(email,senha); if(usuario==null) aviso("Usuário ou senha incorretos."); else abrir("TelaMenu"); }
 public static javax.swing.JPanel painel(String nome) throws Exception { return (javax.swing.JPanel)Class.forName("fabian.balanca.naocai."+nome).getDeclaredConstructor().newInstance(); }
 public static void abrir(String nome) { try { janela.setContentPane(painel(nome)); janela.revalidate(); janela.repaint(); } catch(Exception ex) { aviso(ex.toString()); } }
}
