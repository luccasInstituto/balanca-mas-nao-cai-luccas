package fabian.balanca.naocai;

/** Tela editável na aba Design do NetBeans. */
public class TelaInclusaoEngenheiros extends javax.swing.JPanel {
    public TelaInclusaoEngenheiros() {
        initComponents();
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        titulo = new javax.swing.JLabel();
        rotulo0 = new javax.swing.JLabel();
        campo0 = new javax.swing.JTextField();
        rotulo1 = new javax.swing.JLabel();
        campo1 = new javax.swing.JTextField();
        rotulo2 = new javax.swing.JLabel();
        campo2 = new javax.swing.JTextField();
        salvar = new javax.swing.JButton();
        limpar = new javax.swing.JButton();
        voltar = new javax.swing.JButton();
        setPreferredSize(new java.awt.Dimension(800, 540));
        setLayout(null);
        titulo.setText("Inclusão de Engenheiros");
        add(titulo);
        titulo.setBounds(80, 35, 660, 30);
        rotulo0.setText("Nome do engenheiro");
        add(rotulo0);
        rotulo0.setBounds(65, 120, 280, 30);
        add(campo0);
        campo0.setBounds(350, 120, 280, 30);
        rotulo1.setText("CREA");
        add(rotulo1);
        rotulo1.setBounds(65, 185, 280, 30);
        add(campo1);
        campo1.setBounds(350, 185, 280, 30);
        rotulo2.setText("Data de admissão (dd/mm/aaaa)");
        add(rotulo2);
        rotulo2.setBounds(65, 250, 280, 30);
        add(campo2);
        campo2.setBounds(350, 250, 280, 30);
        salvar.setText("Incluir");
        salvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salvarActionPerformed(evt);
            }
        });
        add(salvar);
        salvar.setBounds(130, 370, 160, 35);
        limpar.setText("Limpar");
        limpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                limparActionPerformed(evt);
            }
        });
        add(limpar);
        limpar.setBounds(320, 370, 160, 35);
        voltar.setText("Voltar");
        voltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voltarActionPerformed(evt);
            }
        });
        add(voltar);
        voltar.setBounds(510, 370, 160, 35);
    }// </editor-fold>//GEN-END:initComponents

    private void salvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salvarActionPerformed
        try { String[] valores = new String[] {campo0.getText(), campo1.getText(), campo2.getText()}; App.dados.inserir(1, valores); App.aviso("Registro salvo com sucesso."); App.abrir("TelaConsultaEngenheiros"); } catch (Exception ex) { App.aviso(ex.getMessage()); }
    }//GEN-LAST:event_salvarActionPerformed

    private void limparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_limparActionPerformed
        campo0.setText(""); campo1.setText(""); campo2.setText("");
    }//GEN-LAST:event_limparActionPerformed

    private void voltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voltarActionPerformed
        App.abrir("TelaManutencaoEngenheiros");
    }//GEN-LAST:event_voltarActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel titulo;
    private javax.swing.JLabel rotulo0;
    private javax.swing.JTextField campo0;
    private javax.swing.JLabel rotulo1;
    private javax.swing.JTextField campo1;
    private javax.swing.JLabel rotulo2;
    private javax.swing.JTextField campo2;
    private javax.swing.JButton salvar;
    private javax.swing.JButton limpar;
    private javax.swing.JButton voltar;
    // End of variables declaration//GEN-END:variables
}
