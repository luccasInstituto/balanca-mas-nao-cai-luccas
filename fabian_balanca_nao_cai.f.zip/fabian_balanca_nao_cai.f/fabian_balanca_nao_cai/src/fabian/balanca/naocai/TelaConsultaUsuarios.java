package fabian.balanca.naocai;

/** Tela editável na aba Design do NetBeans. */
public class TelaConsultaUsuarios extends javax.swing.JPanel {
    public TelaConsultaUsuarios() {
        initComponents();
        carregar();
    }
    private java.util.List<String[]> registros;
    private void carregar() {
        if (App.dados == null) return;
        registros = App.dados.listar(3);
        javax.swing.table.DefaultTableModel modelo = new javax.swing.table.DefaultTableModel(new String[] {"Código", "Nome", "E-mail"}, 0) { public boolean isCellEditable(int r, int c) { return false; } };
        for (String[] r : registros) modelo.addRow(java.util.Arrays.copyOf(r, 3));
        tabela.setModel(modelo); tabela.setRowHeight(28); tabela.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION); tabela.getTableHeader().setReorderingAllowed(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        titulo = new javax.swing.JLabel();
        rolagem = new javax.swing.JScrollPane();
        voltar = new javax.swing.JButton();
        setPreferredSize(new java.awt.Dimension(800, 540));
        setLayout(null);
        titulo.setText("Consulta de Usuários");
        add(titulo);
        titulo.setBounds(80, 35, 660, 30);
        tabela = new javax.swing.JTable();
        tabela.setModel(new javax.swing.table.DefaultTableModel(new Object[][] {}, new String[] {"Código", "Descrição"}));
        rolagem.setViewportView(tabela);
        add(rolagem);
        rolagem.setBounds(55, 100, 690, 280);
        voltar.setText("Voltar");
        voltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voltarActionPerformed(evt);
            }
        });
        add(voltar);
        voltar.setBounds(290, 420, 170, 35);
    }// </editor-fold>//GEN-END:initComponents

    private void voltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voltarActionPerformed
        App.abrir("TelaManutencaoUsuarios");
    }//GEN-LAST:event_voltarActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel titulo;
    private javax.swing.JScrollPane rolagem;
    private javax.swing.JButton voltar;
    private javax.swing.JTable tabela;
    // End of variables declaration//GEN-END:variables
}
