package fabian.balanca.naocai;

/** Tela editável na aba Design do NetBeans. */
public class TelaConsultaEngenheiros extends javax.swing.JPanel {
    public TelaConsultaEngenheiros() {
        initComponents();
        carregar();
    }
    private java.util.List<String[]> registros;
    private void carregar() {
        if (App.dados == null) return;
        registros = App.dados.listar(1);
        javax.swing.table.DefaultTableModel modelo = new javax.swing.table.DefaultTableModel(new String[] {"Código", "Nome do engenheiro", "CREA", "Data de admissão (dd/mm/aaaa)"}, 0) { public boolean isCellEditable(int r, int c) { return false; } };
        for (String[] r : registros) modelo.addRow(java.util.Arrays.copyOf(r, 4));
        tabela.setModel(modelo); tabela.setRowHeight(28); tabela.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION); tabela.getTableHeader().setReorderingAllowed(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        titulo = new javax.swing.JLabel();
        rolagem = new javax.swing.JScrollPane();
        tabela = new javax.swing.JTable();
        voltar = new javax.swing.JButton();

        setPreferredSize(new java.awt.Dimension(800, 540));
        setLayout(null);

        titulo.setText("Consulta de Engenheiros");
        add(titulo);
        titulo.setBounds(80, 35, 660, 30);

        rolagem.setViewportView(tabela);

        add(rolagem);
        rolagem.setBounds(55, 100, 690, 280);

        voltar.setText("Voltar");
        voltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voltarActionPerformed(evt);
            }
        });
        add(voltar);
        voltar.setBounds(290, 420, 170, 35);
    }// </editor-fold>//GEN-END:initComponents

    private void voltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voltarActionPerformed
        App.abrir("TelaManutencaoEngenheiros");
    }//GEN-LAST:event_voltarActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane rolagem;
    private javax.swing.JTable tabela;
    private javax.swing.JLabel titulo;
    private javax.swing.JButton voltar;
    // End of variables declaration//GEN-END:variables
}
