package fabian.balanca.naocai;

/** Tela editável na aba Design do NetBeans. */
public class TelaLogin extends javax.swing.JPanel {
    public TelaLogin() {
        initComponents();
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        titulo = new javax.swing.JLabel();
        rotuloEmail = new javax.swing.JLabel();
        email = new javax.swing.JTextField();
        rotuloSenha = new javax.swing.JLabel();
        senha = new javax.swing.JPasswordField();
        entrar = new javax.swing.JButton();
        cancelar = new javax.swing.JButton();
        setPreferredSize(new java.awt.Dimension(800, 540));
        setLayout(null);
        titulo.setText("Informe seu usuário e senha para entrar.");
        add(titulo);
        titulo.setBounds(80, 35, 660, 30);
        rotuloEmail.setText("Usuário (e-mail):");
        add(rotuloEmail);
        rotuloEmail.setBounds(130, 150, 160, 30);
        add(email);
        email.setBounds(300, 150, 280, 30);
        rotuloSenha.setText("Senha:");
        add(rotuloSenha);
        rotuloSenha.setBounds(130, 200, 160, 30);
        add(senha);
        senha.setBounds(300, 200, 280, 30);
        entrar.setText("ENTRAR");
        entrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                entrarActionPerformed(evt);
            }
        });
        add(entrar);
        entrar.setBounds(180, 290, 180, 35);
        cancelar.setText("CANCELAR");
        cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelarActionPerformed(evt);
            }
        });
        add(cancelar);
        cancelar.setBounds(410, 290, 180, 35);
    }// </editor-fold>//GEN-END:initComponents

    private void entrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_entrarActionPerformed
        App.entrar(email.getText(), new String(senha.getPassword()));
    }//GEN-LAST:event_entrarActionPerformed

    private void cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelarActionPerformed
        email.setText(""); senha.setText("");
    }//GEN-LAST:event_cancelarActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel titulo;
    private javax.swing.JLabel rotuloEmail;
    private javax.swing.JTextField email;
    private javax.swing.JLabel rotuloSenha;
    private javax.swing.JPasswordField senha;
    private javax.swing.JButton entrar;
    private javax.swing.JButton cancelar;
    // End of variables declaration//GEN-END:variables
}
