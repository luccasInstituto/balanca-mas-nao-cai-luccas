package fabian.balanca.naocai;
public class FabianBalancaNaocai {
 public static void main(String[] args) {
  javax.swing.SwingUtilities.invokeLater(() -> { try {
   javax.swing.UIManager.setLookAndFeel(javax.swing.UIManager.getCrossPlatformLookAndFeelClassName());
   App.dados=new Dados(java.nio.file.Paths.get(System.getProperty("fabian.dados","dados/cadastros.xml")));
   App.janela=new javax.swing.JFrame("fabian_balanca_nao_cai");
   App.janela.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
   App.abrir("TelaLogin"); App.janela.pack(); App.janela.setResizable(false); App.janela.setLocationRelativeTo(null); App.janela.setVisible(true);
  } catch(Exception ex) { ex.printStackTrace(); javax.swing.JOptionPane.showMessageDialog(null,ex.getMessage()); } });
 }
}
